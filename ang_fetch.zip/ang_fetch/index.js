const express = require('express'),
    http = require('http'),
    bodyParser = require('body-parser'),
    mongoose = require('mongoose'),
    path = require('path');

global.mongoose = mongoose;

var app = express();

var server = http.createServer(app);
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({}));
app.use(express.static(__dirname + '/public'));

require('./database/database');
require('./model/registration');
require('./routes/routes')(app);

app.route('/*').get(function(req, res) {
    res.sendFile(path.resolve('./public' + '/index.html'));
});

server.listen(3000, function() {
    console.log('Server is listening on port 3000.');
})