var schema = mongoose.Schema;

var registrationSchema = new schema({
    'Firstname': { type: String },
    'lastname': { type: String },
    'MobileNumber': { type: String },
    'Email': { type: String },
    'Address': { type: String }
});

exports.registration = mongoose.model('registration', registrationSchema);