var dburi = 'mongodb://localhost:27017/jyotidb';
mongoose.connect(dburi, { useNewUrlParser: true });

mongoose.connection.on("connected", function() {
    console.log("Database Connected successfully");
});

mongoose.connection.on("error", function() {
    console.log("Database Connection failed");
});