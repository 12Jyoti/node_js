require('../model/registration.js');
var registrationModel = mongoose.model('registration');

exports.saveRegistration = function(req, res) {
    var registrationData = new registrationModel(req.body);
    console.log(req.body);
    registrationData.save(function(err, result) {
        if (result) {
            console.log("Saved Successfully");
            res.redirect('/');
        }
    });
}
exports.getUserList = function(req, res) {
    registrationModel.find({}, function(err, result) {
        res.status(200).json({ result: result });
    })
}