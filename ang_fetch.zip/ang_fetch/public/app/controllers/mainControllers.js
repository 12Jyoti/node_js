firstApp.controller('registrationController', ['$scope', 'mainService', '$http', '$state', function($scope, mainService, $http, $state) {

    $scope.saveRegistration = function(registrationData) {
        mainService.saveRegistration(registrationData)
            .then(function(response) {
                $state.go('home.main');
            })
            .catch(function(error) {

            })
    }
}]);
firstApp.controller('homeMainController', ['$scope', 'getUserList', function($scope, getUserList) {
    $scope.userList = getUserList.data.result;

}]);